SAHABAT REMAJA — VERCEL STARTER

KANDUNGAN
- 7 halaman asal dikekalkan sebagai fail HTML berasingan.
- Chat Luna the Bunny dimasukkan pada bantuan.html sahaja.
- Avatar Luna: assets/luna-bunny.png
- Muzik diekstrak daripada lagu-website-fixed.html ke assets/background-music.mp3; kawalan ON/OFF ditambah pada setiap halaman (main selepas pengguna tekan).
- API backend: api/chat.js

PENTING
1. Jangan masukkan API key dalam mana-mana fail HTML/JS.
2. Di Vercel Project > Settings > Environment Variables, tambah:
   Name: GEMINI_API_KEY
   Value: (API key Gemini anda)
   Environment: Production, Preview, Development
3. Redeploy selepas menyimpan variable.
4. API key tidak termasuk dalam ZIP ini.

DEPLOY
- Import folder ini sebagai projek Vercel (paling mudah melalui GitHub repository).
- Vercel menyokong /api/chat.js sebagai serverless function.

NOTA PEMBANGUNAN
Fail HTML asal dikekalkan tanpa reka bentuk semula. Chatbot Luna ditambah hanya pada halaman Bantuan dan Sokongan.
Pautan navigasi menyeluruh, suis bahasa penuh, responsif menyeluruh dan skor untuk semua aktiviti memerlukan pemeriksaan dan pengujian halaman satu demi satu; ia tidak didakwa siap hanya berdasarkan starter ini.
