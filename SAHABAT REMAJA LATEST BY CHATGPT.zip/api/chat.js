export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(503).json({ error: 'Gemini API belum dikonfigurasi. Tambahkan GEMINI_API_KEY dalam Vercel Environment Variables.' });
  const message = String(req.body?.message || '').trim().slice(0, 1200);
  if (!message) return res.status(400).json({ error: 'Mesej kosong.' });
  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-8) : [];
  const contents = [...history.filter(x => ['user','model'].includes(x.role) && typeof x.text === 'string').map(x => ({ role:x.role, parts:[{text:x.text.slice(0,1200)}] })), { role:'user', parts:[{text:message}] }];
  const system = `Anda ialah Luna the Bunny, pembantu maya mesra untuk laman Sahabat Remaja yang membincangkan kesejahteraan mental dan keselamatan digital. Jawab dalam bahasa yang digunakan pengguna (Bahasa Melayu atau English), dengan nada lembut, ringkas, tidak menghakimi dan sesuai untuk remaja. Berikan sokongan umum, strategi kendiri yang selamat dan langkah keselamatan digital. Jangan mendiagnosis atau mendakwa sebagai ahli terapi. Jangan minta nama penuh, alamat, nombor telefon, kata laluan atau maklumat pengenalan. Jika pengguna menyatakan risiko mencederakan diri, bunuh diri, penderaan atau bahaya segera, ambil serius, galakkan mereka mendapatkan orang dewasa dipercayai sekarang dan hubungi perkhidmatan kecemasan tempatan; di Malaysia, 999 untuk kecemasan. Nyatakan bahawa AI bukan pengganti kaunselor atau bantuan kecemasan.`;
  try {
    const response = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent', { method:'POST', headers:{'Content-Type':'application/json','x-goog-api-key':key}, body:JSON.stringify({ systemInstruction:{parts:[{text:system}]}, contents, generationConfig:{temperature:0.7,maxOutputTokens:700} }) });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: data?.error?.message || 'Gemini API request failed.' });
    const reply = data?.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('').trim();
    return res.status(200).json({ reply: reply || 'Maaf, Luna belum dapat menjawab sekarang.' });
  } catch (e) { return res.status(500).json({ error:'Ralat pelayan semasa menghubungi Gemini.' }); }
}
